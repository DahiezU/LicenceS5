from tkinter import *
from tkinter.filedialog import askopenfilename,askopenfile
import TestClass
    


class Interface(Frame):
    
    """Notre fenêtre principale.
    Tous les widgets sont stockés comme attributs de cette fenêtre."""
    
    def __init__(self, fenetre, **kwargs):
        Frame.__init__(self, fenetre, width=0, height=0, **kwargs)
        #self.pack(fill=BOTH)

        
        #Creation Label
        ''' l1.grid(row=0, column=0, padx=(100, 10))
        l2.grid(row=1, column=0, padx=(10, 100)) '''

        LabelTitre = Label(fenetre, text="ALGORYTHME KNN")
        LabelTitre.grid(sticky = N,row=0, column = 1 )
        
        self.labelSelectFileTrain = Label(fenetre, text="Selectionner le fichier csv d'entrainnement")
        self.labelSelectFileTrain.grid(sticky = W,row=1, pady=(30,2) , padx=(5,0))

        self.labelSelectFileTest = Label(fenetre, text="Selectionner le fichier csv de Test")
        self.labelSelectFileTest.grid(sticky = W,row=2 , padx=(5,0))

        self.labelSelectKVoisins = Label(fenetre, text="Saisir le nombre de K voisins")
        self.labelSelectKVoisins.grid(sticky = W,row=3 ,pady=(30,2) , padx=(5,0))

        self.labelSelectnbColonne = Label(fenetre, text="Saisir l'index de la  colonne à test :")
        self.labelSelectnbColonne.grid(sticky = W,row=4 , padx=(5,0))

        self.Res = Label(fenetre, text="Resultat :")
        self.Res.grid(sticky = W,row= 5 , padx=(20,0), pady=(10,10))
        
        # Création input
        #self.varTrainData = StringVar()
        self.inputFileNameTrain= Entry(fenetre, text="", width=110)
        self.inputFileNameTrain.grid(row=1, column =1 ,pady=(30,2) , padx=(20))

        #self.varTestData = StringVar()
        self.inputFileNameTest= Entry(fenetre, text ="", width=110)
        self.inputFileNameTest.grid(row=2, column =1 )

        #self.varKVoisins = IntVar()
        self.inputKVoisins= Entry(fenetre, text="", width=10)
        self.inputKVoisins.grid(sticky = W,row=3, column =1 ,pady=(30,2))

        #self.varNColonne = IntVar()
        self.inputNColonne= Entry(fenetre, text="", width=10)
        self.inputNColonne.grid(sticky = W,row=4, column =1)

        self.monres = ""
        
        self.inputRes= Entry(fenetre, text=self.monres, width=40)
        self.inputRes.grid(sticky = W,row=5, column =1 , pady=(10,10))
        self.inputRes.config(state='disabled')
        #Creation bouton
        

        self.boutonSelectFileTrain = Button(fenetre, text="Charger csv" , command=self.browsecsvTrain)
        self.boutonSelectFileTrain.grid(sticky = W ,row=1, column =2 ,pady=(30,2))

        self.boutonSelectFileTest = Button(fenetre, text="Charger csv" , command=self.browsecsvTest)
        self.boutonSelectFileTest.grid(sticky = W ,row=2, column =2)
        
        
        self.boutonLancer = Button(fenetre, text="Calculer" , command=self.FonctionFinale)
        self.boutonLancer.grid(sticky = N ,row=4, column =2)
 
        
    
    def browsecsvTrain(self):
        self.inputFileNameTrain.delete(0,'end')
        Tk().withdraw() 
        filename = askopenfilename()
        self.inputFileNameTrain.insert(0, filename) 
        #self.inputFileNameTrain.config(state='disabled')
    
    def browsecsvTest(self):
        self.inputFileNameTest.delete(0,'end')
        Tk().withdraw() 
        filename = askopenfilename()
        self.inputFileNameTest.insert(0, filename) 
    
    def TestDataType(self):
        extensionTrain = self.inputFileNameTrain.get().split('.')[-1]
        extensionTest = self.inputFileNameTest.get().split('.')[-1]
        if( extensionTrain != "csv"):
            self.inputFileNameTrain.delete(0, 'end')
            self.inputFileNameTest.delete(0, 'end')   
            return False
        elif(extensionTest != "csv"):
            self.inputFileNameTrain.insert(0,"ERROR TYPE FICHIER")
            self.inputFileNameTest.insert(0,"ERROR TYPE FICHIER")
            return False
        else:
            return True

    def TestNum(self,test):
        numCol = self.inputNColonne.get()
        numVoisin = self.inputKVoisins.get()
        print(len(test.testFileConvert))
        print(test.testFileConvert)
        try:
            if(int(numCol) > len(test.testFileConvert)-1 or int(numCol) < 0 ):
                self.inputNColonne.delete(0, 'end')
                self.inputNColonne.insert(0,"ERROR")
                return False
            elif(int(numVoisin) > len(test.trainFileConvert[0])-1 or int(numVoisin) <= 0):
                self.inputKVoisins.delete(0, 'end')
                self.inputKVoisins.insert(0,"ERROR")
                return False
            else:
                return True
        except:
            self.inputNColonne.delete(0, 'end')
            self.inputNColonne.insert(0,"ERROR")
            self.inputKVoisins.delete(0, 'end')
            self.inputKVoisins.insert(0,"ERROR")
            return False

    def FonctionFinale(self):
        if(self.TestDataType()):
            self.inputRes.config(state='normal')
            self.inputRes.delete(0, 'end')
            montest = TestClass.MiniIa(self.inputFileNameTrain.get(),self.inputFileNameTest.get(),self.inputNColonne.get(), self.inputKVoisins.get())
            montest.OpenFile()
            montest.TableToFloat()
            if(self.TestNum(montest)):
                montest.MaxColonne()
                montest.MinColonne()
                montest.Euclidienne1()
                montest.ClassementCroissantLigne()
                #self.monres = montest.CorrespondanceVoisin()
                self.inputRes.insert(0,"Classe :  " + montest.CorrespondanceVoisin())
            self.inputRes.config(state='disabled')
        
        


fenetre = Tk()
fenetre.geometry('1100x300')
fenetre.title('KNN')
interface = Interface(fenetre)
interface.mainloop()
interface.destroy()