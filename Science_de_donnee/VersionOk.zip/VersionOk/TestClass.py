import csv
import math



class MiniIa:
    
    def __init__(self, trainFile , testFile,numCollonne,kVoisins):
        #Colonne à chercher
        self.numCollonne = numCollonne

        #KVoisins
        self.kVoisins = kVoisins

        #Fichier csv pur
        self.trainFile = trainFile
        self.testFile = testFile
        
         #Fichier csv lisible
        self.trainFileConvert = []
        self.testFileConvert = []
        
        #Noms values à rechercher
        self.valuesName = []

        #Min et Max Collonnes
        self.listMax = []
        self.listMin = []

        #Tableau des calculs
        self.tableCalculs = []

        #Moyenn Medianne
        self.moyenne = []
        self.medianne = []
    

    def OpenFile(self):
        fileTrain = open(self.trainFile)
        fileTest = open(self.testFile)

        csvTrain = csv.reader(fileTrain, delimiter=',', quotechar='|')
        csvTest = csv.reader(fileTest, delimiter=',', quotechar='|')
       
        next(csvTrain)
        next(csvTest)
        
        for rowTrain in csvTrain:
            self.trainFileConvert.append(rowTrain)
         
        for rowTest in csvTest:
            self.testFileConvert.append(rowTest)


    def StringToInt(self,texte):
        val = 0.0
        for c in texte:
            val += float(ord(c))
        return val

 
    '''def TableToFloat(self):
        for ligne in range(len(self.trainFileConvert)):
            for carac in range(len(self.trainFileConvert[ligne])) :
                try: 
                    self.trainFileConvert[ligne][carac] = float(self.trainFileConvert[ligne][carac])
                except:
                    if(((self.trainFileConvert[ligne][carac],self.StringToInt(self.trainFileConvert[ligne][carac])) in self.valuesName) == False):
                        self.valuesName.append((self.trainFileConvert[ligne][carac],self.StringToInt(self.trainFileConvert[ligne][carac])))
                    self.trainFileConvert[ligne][carac] = self.StringToInt(self.trainFileConvert[ligne][carac])

        print(self.valuesName)            
        
        for ligne in range(len(self.testFileConvert)):
            for carac in range(len(self.testFileConvert[ligne])) :
                try: 
                    self.testFileConvert[ligne][carac] = float(self.testFileConvert[ligne][carac])
                except:
                    #if(((self.testFileConvert[ligne][carac],self.StringToInt(self.testFileConvert[ligne][carac])) in self.valuesName) == False):
                        #self.valuesName.append((self.testFileConvert[ligne][carac],self.StringToInt(self.testFileConvert[ligne][carac])))
                    self.testFileConvert[ligne][carac] = self.StringToInt(self.testFileConvert[ligne][carac])'''
     
    def TableToFloat(self):
        for ligne in range(len(self.trainFileConvert)):
            for carac in range(len(self.trainFileConvert[ligne])) :
                try: 
                    self.trainFileConvert[ligne][carac] = float(self.trainFileConvert[ligne][carac])
                except:
                    if(((self.trainFileConvert[ligne][carac],self.StringToInt(self.trainFileConvert[ligne][carac])) in self.valuesName) == False):
                        self.valuesName.append((self.trainFileConvert[ligne][len(self.trainFileConvert[ligne])-1],self.StringToInt(self.trainFileConvert[ligne][len(self.trainFileConvert[ligne])-1])))
                        
                    self.trainFileConvert[ligne][carac] = self.StringToInt(self.trainFileConvert[ligne][carac])
        
        #print(self.valuesName)            
        
        for ligne in range(len(self.testFileConvert)):
            for carac in range(len(self.testFileConvert[ligne])) :
                try: 
                    self.testFileConvert[ligne][carac] = float(self.testFileConvert[ligne][carac])
                except:
                    #if(((self.testFileConvert[ligne][carac],self.StringToInt(self.testFileConvert[ligne][carac])) in self.valuesName) == False):
                        #self.valuesName.append((self.testFileConvert[ligne][carac],self.StringToInt(self.testFileConvert[ligne][carac])))
                    self.testFileConvert[ligne][carac] = self.StringToInt(self.testFileConvert[ligne][carac])

    def MaxColonne(self):
        for carac in range(len(self.trainFileConvert[0])):
            varMax = 0
            for ligne in range(len(self.trainFileConvert)): 
                if(float(self.trainFileConvert[ligne][carac]) > float(varMax)):
                    varMax = self.trainFileConvert[ligne][carac]
            self.listMax.append(varMax)
        #print(self.listMax[len(self.listMax)-1])
        #print(self.listMax)

    def MinColonne(self):
        for carac in range(len(self.trainFileConvert[0])):
            varMin = self.trainFileConvert[0][0]
            for ligne in range(len(self.trainFileConvert)): 
                if(float(self.trainFileConvert[ligne][carac]) < float(varMin)):
                    varMin = self.trainFileConvert[ligne][carac]
            self.listMin.append(varMin)
        #print(self.listMin[len(self.listMin)-1])
        #print(self.listMin)

    def Euclidienne(self):
        var = self.trainFileConvert
        for ligneTest in self.testFileConvert: 
            intermediaire = []
            for ligneTraining in  var:
                formule = 0
                i = 0
                for caracTest,caracTraining in zip(ligneTest,ligneTraining):
                    print("   Mon min == " , self.listMax , "   Mon max == " , self.listMin)
                    if(self.listMax[i] == self.listMin[i]):
                        print("\nddddeeeeeeeeeeeeeeee\n")
                        self.listMax[i] +=1
                    formule += pow((float(caracTraining)-float(caracTest))/(float(self.listMax[i])-float(self.listMin[i])), 2)   
                    i +=1
                intermediaire.append(math.sqrt(formule)) 
            self.tableCalculs.append(intermediaire)
        print("Euclidienne \n")
        print(self.tableCalculs)

    def Euclidienne1(self):
        var = self.trainFileConvert
        
        intermediaire = []
        #print(self.trainFileConvert)
        for ligneTraining in  var:
            formule = 0
            i = 0
            for caracTest,caracTraining in zip(self.testFileConvert[int(self.numCollonne)],ligneTraining):
                #print("   Mon min == " , self.listMin[i] , "   Mon max == " , self.listMax[i])
                if(self.listMax[i] == self.listMin[i]):
                        #print("\nddddeeeeeeeeeeeeeeee\n")
                        self.listMax[i] +=1
                formule += pow((float(caracTraining)-float(caracTest))/(float(self.listMax[i])-float(self.listMin[i])), 2)   
                i +=1
                #print('CaracTest  ', caracTest , ' ///// ' ,'CaracTrainig  ', caracTraining , '    Formule ==' , formule)
            
            intermediaire.append(math.sqrt(formule)) 
            #print(' \n Intermediare = ' ,  intermediaire)
        self.tableCalculs.append(intermediaire)
        '''print("Euclidienne \n")
        print(self.tableCalculs)'''
     

    def Moyenne(self):
        moyenne = 0
        for ligne in self.tableCalculs:
            inc = 0
            for valeur in ligne:
                moyenne += valeur
                inc+=1
            moyenne /= len(self.tableCalculs[0])
            self.moyenne.append(moyenne) 
        '''print("Moyenne \n")
        print(self.moyenne)'''

    def MoyenneLigne(self):
        moyenne = 0
        for ligne in self.tableCalculs:
            inc = 0
            for valeur in ligne:
                moyenne += valeur
                inc+=1
            moyenne /= len(self.tableCalculs[0])
            self.moyenne.append(moyenne) 
        print("Moyenne \n")
        print(self.moyenne)

    def ClassementCroissantLigne(self):
        listSorted  = self.tableCalculs
        #print(listSorted[0])
        listSorted = sorted(listSorted[0])
        #print(listSorted)
        return listSorted

    def FindVoisins(self):
        listeVoisin = []
        i=0
        #print(self.ClassementCroissantLigne()[0])
        #a = self.ClassementCroissantLigne()[0]
        for  i in range(int(self.kVoisins)):
            listeVoisin.append(self.ClassementCroissantLigne()[i])
        valeurIndex = []
        
        for voisin in listeVoisin:
            for valeur in self.tableCalculs[0]:
                    if(float(voisin) == float(valeur)):
                        #print(self.tableCalculs[0].index(valeur))
                        valeurIndex.append(self.tableCalculs[0].index(valeur))
        #print(sorted(valeurIndex) , " \n")    
        return sorted(valeurIndex)

    def ValeurVoisins(self):
        liste = self.FindVoisins()
        valeur  = []
        #print(self.trainFileConvert)
        for indexVoisin in liste:
            #print(self.trainFileConvert[indexVoisin][len(self.trainFileConvert[0])-1])
            valeur.append(self.trainFileConvert[indexVoisin][len(self.trainFileConvert[0])-1])
        '''print('\nValeur voisin \n')
        print(valeur)
        print('\n FIN Valeur voisin \n')'''
        return valeur
    
    def CorrespondanceVoisin(self):
        dictValeur = {i:self.ValeurVoisins().count(i) for i in  self.ValeurVoisins()}
        {k: v for k, v in sorted(dictValeur.items(), key=lambda item: item[1])}
        #print({k: v for k, v in sorted(dictValeur.items(), key=lambda item: item[1])})
        #print ((list({k: v for k, v in sorted(dictValeur.items(), key=lambda item: item[1])}.items())[-1])[0])
        voisinVal = (list({k: v for k, v in sorted(dictValeur.items(), key=lambda item: item[1])}.items())[-1])[0]
        #return  (list({k: v for k, v in sorted(dictValeur.items(), key=lambda item: item[1])}.items())[-1])[0] 
        '''print('\nValeur donné varaible \n')
        print(self.valuesName)
        print('\n FIN Valeur donné varaible \n')'''
        for Val in self.valuesName:
            '''print('aaa')
            print(Val)'''
            if(Val[1] == voisinVal ):
                print("Champi de nb colone : " , self.numCollonne ," est " , Val[0] , " \n")
                #print(Val[0])
                return Val[0]
            


pathTrain = "C:\\Users\\sburd\\Desktop\\CoursSDNL3S1\\science_données\\Projet_champi\\csv\\detecteur_citrons_training.csv"
pathTest = "C:\\Users\\sburd\\Desktop\\CoursSDNL3S1\\science_données\\Projet_champi\\csv\\detecteur_citrons_test.csv"

pathChampiTrain = "C:\\Users\\sburd\\Desktop\\CoursSDNL3S1\\science_données\\Projet_champi\\csv\\tp_mushrooms_dataset_150.csv"
pathChampiTest = "C:\\Users\\sburd\\Desktop\\CoursSDNL3S1\\science_données\\Projet_champi\\csv\\tp_mushrooms_eval_etu_id.csv"


'''test = MiniIa(pathTrain,pathTest,0,2)
test.OpenFile()
test.TableToFloat()
test.MaxColonne()
test.MinColonne()
test.Euclidienne1()
test.ClassementCroissantLigne()
test.CorrespondanceVoisin()'''


'''testC = MiniIa(pathChampiTrain,pathChampiTest,0,10)
testC.OpenFile()
testC.TableToFloat()
testC.MaxColonne()
testC.MinColonne()
testC.Euclidienne1()
testC.ClassementCroissantLigne()
testC.CorrespondanceVoisin()

testC1 = MiniIa(pathChampiTrain,pathChampiTest,1,10)
testC1.OpenFile()
testC1.TableToFloat()
testC1.MaxColonne()
testC1.MinColonne()
testC1.Euclidienne1()
testC1.ClassementCroissantLigne()
testC1.CorrespondanceVoisin()

testC2 = MiniIa(pathChampiTrain,pathChampiTest,2,10)
testC2.OpenFile()
testC2.TableToFloat()
testC2.MaxColonne()
testC2.MinColonne()
testC2.Euclidienne1()
testC2.ClassementCroissantLigne()
testC2.CorrespondanceVoisin()


testC3 = MiniIa(pathChampiTrain,pathChampiTest,3,10)
testC3.OpenFile()
testC3.TableToFloat()
testC3.MaxColonne()
testC3.MinColonne()
testC3.Euclidienne1()
testC3.ClassementCroissantLigne()
testC3.CorrespondanceVoisin()


testC4 = MiniIa(pathChampiTrain,pathChampiTest,4,10)
testC4.OpenFile()
testC4.TableToFloat()
testC4.MaxColonne()
testC4.MinColonne()
testC4.Euclidienne1()
testC4.ClassementCroissantLigne()
testC4.CorrespondanceVoisin()'''

