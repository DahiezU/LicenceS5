install.packages("tinytex")
Pour compiler le pdf